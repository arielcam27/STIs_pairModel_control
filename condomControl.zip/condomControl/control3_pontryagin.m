clear all;

syms s mu I rho X1 h Xe phi P01 gama
syms B u

dx1 = (s+mu)*I-(2*mu+rho+s)*X1-gama*X1;
dx2 = rho*(1-h*(1-u))*X1*(1-X1/Xe)-(s+phi*h*(1-u)+2*mu)*P01+gama*(I-X1-2*P01);
dx3 = rho*h*(1-u)*X1*(1-X1/Xe)+phi*h*(1-u)*P01-mu*I-gama*I;

syms l1 l2 l3

H = l1*dx1 + l2*dx2 + l3*dx3 + I + B*u^2;

dl1 = -diff(H,X1);
disp(dl1);
dl2 = -diff(H,P01);
disp(dl2);
dl3 = -diff(H,I);
disp(dl3);

du = diff(H,u);

solve(du,u)
